import { useContext } from "react";
import { CartContext } from "./CartContext";

export default function MenuCardItem({ item }) {
    const { addToCart } = useContext(CartContext);

    return (
        <div >
            <img src={item.image} alt={item.name}/>
            <h3 > {item.name} </h3>
             <p> ${item.price} </p>
             <button onClick={() => addToCart(item)}>
                Add to Cart
             </button>
        </div>
    )
};