import { Link } from "react-router-dom";
import menuData from "../assets/menu.json";

export default function Home() {
    const featured = menuData.slice(0,3);

    return (
    <div>
      {/* ===== Hero Section ===== */}
      <section>
        <h1>Welcome to TasteBite 🍽️</h1>
        <p>
          Fresh. Fast. Delicious. Your favorite meals delivered right to your door.
        </p>
        <Link
          to="/menu"
        >
          Order Now
        </Link>
      </section>

      {/* ===== Featured Dishes ===== */}
      <section>
        <h2>Featured Dishes</h2>
        <div>
          {featured.map((item) => (
            <div
              key={item.id}
            >
              <img
                src={item.image}
                alt={item.name}
              />
              <div>
                <h3>{item.name}</h3>
                <p>${item.price.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== About Section ===== */}
      <section>
        <h2>About Us</h2>
        <p>
          At TasteBite, we’re passionate about creating flavorful dishes using
          fresh ingredients. Whether you’re craving pizza, pasta, or dessert,
          we make it with love and serve it fast.
        </p>
      </section>
    </div>
  );

}
