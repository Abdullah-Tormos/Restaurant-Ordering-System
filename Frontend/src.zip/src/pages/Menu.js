import menuData from '../assets/menu.json'
import MenuCardItem from '../components/MenuItemCard'

export default function Menu() {
    return (
        <div className='menu'>
        {menuData.map((item) => (
            <MenuCardItem key={item.id} item={item}/>
        ))}
        </div>
    )
}