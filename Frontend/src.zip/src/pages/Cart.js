import { useContext } from "react";
import { CartContext } from "../components/CartContext";
import { Link, useNavigate } from "react-router-dom";
import '../styles/Cart.css'

export default function Cart() {
  const { cart, addToCart, removeFromCart, clearCart } = useContext(CartContext);
  const navigate = useNavigate();

  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert("Your cart is empty!");
      return;
    }
    navigate("/Checkout");
  };

  return (
    <div >
      <h1>Your Cart</h1>

      {cart.length === 0 ? (
        <div>
          <p>Your cart is empty.</p>
          <Link
            to="/menu"
          >
            Go to Menu
          </Link>
        </div>
      ) : (
        <>
          <div>
            {cart.map((item) => (
              <div
                key={item.id}
              >
                <div>
                  <img
                    src={item.image}
                    alt={item.name}
                    
                  />
                  <div>
                    <h3>{item.name}</h3>
                    <p>${item.price.toFixed(2)}</p>
                  </div>
                </div>

                <div>
                  <button
                    onClick={() => removeFromCart(item.id)}
                  >
                    −
                  </button>
                  <span>{item.quantity}</span>
                  <button
                    onClick={() => addToCart(item)}
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div>
            <h2>
              Total: <span>${totalPrice}</span>
            </h2>

            <div>
              <button
                onClick={clearCart}
              >
                Clear Cart
              </button>

              <button
                onClick={handleCheckout}
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
