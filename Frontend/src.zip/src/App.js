import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './components/CartContext'
import Home from "./pages/Home.js";
import Menu from "./pages/Menu.js";
import Cart from "./pages/Cart.js";
import './App.css'

import Navbar from './components/Navbar';
import Checkout from './pages/Checkout.js';

function App() {

  return (
    <CartProvider>
      <Router>
        <div>
        <Navbar/>
        <Routes>
          <Route path='/' Component={Home}/>
          <Route path='/Menu' Component={Menu}/>
          <Route path='/Cart' Component={Cart}/>
          <Route path='/Checkout' Component={Checkout}/>
        </Routes>
        </div>

      </Router>
    </CartProvider>
  )
}

export default App;