import {Link} from 'react-router-dom'
import {useState} from 'react' 
import ReOrderIcon from '@mui/icons-material/Reorder'
import '../styles/Navbar.css'

 const Navbar = () => {
    const [openLinks, setOpenLinks] = useState(false);

    const toggleNavbar = () => {
        setOpenLinks(!openLinks);
    }

    return(
        <div className='navbar'>
            <div className='hiddenLinks' id={openLinks ? "open" : "close"}>
                <Link to="/" onClick={() => setOpenLinks(false)}> Home </Link>
                <Link to="/Menu" onClick={() => setOpenLinks(false)}> Menu </Link>
                <Link to="Cart" onClick={() => setOpenLinks(false)}> Cart </Link>
            </div> 

            <div className='rightSide'>
                <Link to="/"> Home </Link>
                <Link to="/Menu"> Menu </Link>
                <Link to="Cart"> Cart </Link>
                <button onClick={toggleNavbar}>
                    <ReOrderIcon/>
                </button>
            </div>
        </div>
    )
}

export default Navbar;